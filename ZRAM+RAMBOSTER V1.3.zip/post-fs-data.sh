#!/system/bin/sh

# Configuración inicial ZRAM
echo 1536M > /sys/block/zram0/disksize
mkswap /dev/block/zram0
swapon /dev/block/zram0

# Optimización de caché
echo 50 > /proc/sys/vm/vfs_cache_pressure
echo 100 > /proc/sys/vm/swappiness
