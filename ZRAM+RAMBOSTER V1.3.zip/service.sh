#!/system/bin/sh

# Iniciar servicio en segundo plano
nohup /system/bin/rambooster >/dev/null�2>&1�&
